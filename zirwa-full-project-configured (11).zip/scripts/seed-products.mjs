#!/usr/bin/env node
// OPTIONAL command-line seeding (the SQL file supabase/05_seed_demo_products.sql does the same
// job from the Supabase dashboard, with no keys on your computer).
// Safe to run many times: existing slugs are skipped.
//   node --env-file=.env scripts/seed-products.mjs
import { readFileSync } from 'node:fs';

const rows = JSON.parse(readFileSync(new URL('../data/demo-products.json', import.meta.url), 'utf8'));
const url = (process.env.SUPABASE_URL || '').replace(/\/+$/, ''), key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) { console.error('Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in a local .env file (never upload it).'); process.exit(1); }

const res = await fetch(`${url}/rest/v1/products?on_conflict=slug`, {
  method: 'POST',
  headers: { apikey: key, authorization: `Bearer ${key}`, 'content-type': 'application/json', prefer: 'resolution=ignore-duplicates,return=representation' },
  body: JSON.stringify(rows),
});
if (!res.ok) { console.error('Seed failed:', res.status, await res.text()); process.exit(1); }
const inserted = await res.json();
console.log(`Inserted ${inserted.length} new product(s); ${rows.length - inserted.length} already existed and were left untouched.`);
