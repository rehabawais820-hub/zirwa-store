#!/usr/bin/env node
// Rebuilds the 54 demo products EXACTLY as your original storefront generated them.
// It runs scripts/source/script.original.js (your original site script) inside an isolated sandbox
// (no network, no file access), reads the generated PRODUCTS array, and writes:
//   data/demo-products.json  and  supabase/05_seed_demo_products.sql
// Usage:  node scripts/extract-demo-products.mjs
import vm from 'node:vm';
import { readFileSync, writeFileSync } from 'node:fs';
import { buildSeedSql } from './seed-sql.mjs';

const SRC = new URL('./source/script.original.js', import.meta.url);
export const COLOR_KEYS = ['blush', 'rose', 'mocha', 'sage', 'sky', 'charcoal', 'ivory', 'wine', 'emerald', 'sand'];
export const CATEGORY_SLUGS = ['dresses', 'coords', 'tops', 'bottoms', 'abayas', 'unisex'];
export const DEFAULT_STOCK = 25; // your original site had no stock numbers; edit real stock in the admin panel

export function extractOriginalProducts(source = readFileSync(SRC, 'utf8')) {
  const marker = 'var byId = function';
  if (!source.includes(marker)) throw new Error('Unexpected original script: marker not found');
  const patched = source.replace(marker, 'globalThis.__EXPORT_PRODUCTS__ = PRODUCTS; ' + marker);
  const noop = () => {};
  const sandbox = {
    console: { log: noop, warn: noop, error: noop },
    localStorage: { getItem: () => null, setItem: noop },
    document: { addEventListener: noop }, window: {}, location: { search: '' },
  };
  sandbox.globalThis = sandbox;
  vm.runInContext(patched, vm.createContext(sandbox), { timeout: 3000 });
  const list = sandbox.__EXPORT_PRODUCTS__;
  if (!Array.isArray(list)) throw new Error('Could not read PRODUCTS from the original script');
  return JSON.parse(JSON.stringify(list));
}

const slugify = (s) => s.toLowerCase().replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

export function toRows(products) {
  const used = new Set();
  return products.map((p) => {
    let slug = slugify(p.name), n = 1;
    while (used.has(slug)) slug = `${slugify(p.name)}-${++n}`;
    used.add(slug);
    return {
      legacy_id: p.id, slug, name: p.name, description: p.desc, category_slug: p.cat,
      // "was" is the old/higher price shown struck-through. Regular price = was; price actually charged = price.
      price_pkr: p.was ? p.was : p.price,
      sale_price_pkr: p.was ? p.price : null,
      sizes: p.sizes, colors: p.colors, stock: DEFAULT_STOCK, images: [],
      is_active: true, is_demo: true, is_new: !!p.isNew, is_bestseller: !!p.best,
    };
  });
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const rows = toRows(extractOriginalProducts());
  if (rows.length !== 54) { console.error(`Expected 54 products, found ${rows.length}`); process.exit(1); }
  writeFileSync(new URL('../data/demo-products.json', import.meta.url), JSON.stringify(rows, null, 2) + '\n');
  writeFileSync(new URL('../supabase/05_seed_demo_products.sql', import.meta.url), buildSeedSql(rows));
  console.log(`OK: ${rows.length} products -> data/demo-products.json + supabase/05_seed_demo_products.sql`);
}
