import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { toRows, extractOriginalProducts } from '../scripts/extract-demo-products.mjs';

// Load the real browser file with a stubbed browser environment.
function load({ fetchImpl } = {}) {
  const store = new Map();
  globalThis.window = undefined;
  const root = { ZIRWA_CONFIG: { SUPABASE_URL: 'https://x.supabase.co', SUPABASE_ANON_KEY: 'anon' },
    sessionStorage: { getItem: (k) => store.get(k) ?? null, setItem: (k, v) => store.set(k, String(v)), removeItem: (k) => store.delete(k) },
    crypto: { randomUUID: (() => { let n = 0; return () => `00000000-0000-4000-8000-${String(++n).padStart(12, '0')}`; })() } };
  const src = (await_import()).replace("})(typeof window !== 'undefined' ? window : globalThis);", '})(__ROOT__);');
  const fn = new Function('__ROOT__', 'fetch', 'module', src);
  const mod = { exports: {} }; fn(root, fetchImpl || (async () => { throw new Error('no fetch'); }), mod);
  return { api: root.ZirwaAPI, store, root };
}
import { readFileSync } from 'node:fs';
function await_import() { return readFileSync(new URL('../public/js/zirwa-api.js', import.meta.url), 'utf8'); }

const rows = toRows(extractOriginalProducts());
const dbRows = rows.map((r, i) => ({ id: `10000000-0000-4000-8000-${String(i + 1).padStart(12, '0')}`, description: r.desc ?? r.description, ...r, images: [] }));

test('shape(): sale items show regular price struck-through and charge the sale price', () => {
  const { api } = load(); const sale = dbRows.find((r) => r.sale_price_pkr); const p = api.shape(sale, 0);
  assert.equal(p.price, sale.sale_price_pkr); assert.equal(p.was, sale.price_pkr); assert.equal(p.type, { dresses: 'dress', coords: 'coord', tops: 'top', bottoms: 'bottom', abayas: 'abaya', unisex: 'unisex' }[sale.category_slug]);
  const plain = api.shape(dbRows.find((r) => !r.sale_price_pkr), 1); assert.equal(plain.was, 0);
});
test('shape(): unsafe image URLs and unknown colours are dropped', () => {
  const { api } = load(); const p = api.shape({ ...dbRows[0], images: ['https://x.supabase.co/a.jpg', 'javascript:alert(1)', 'https://x/"onerror="1', '/rel.jpg'], colors: ['sky', 'neon'] }, 0);
  assert.deepEqual(p.images, ['https://x.supabase.co/a.jpg']); assert.deepEqual(p.colors, ['sky']);
});
test('reconcileCart(): old z-ids upgrade, sold-out/invalid variants removed, qty capped', () => {
  const { api } = load(); const products = dbRows.map(api.shape);
  products[1].stock = 0; products[2].stock = 2;
  const cart = [{ id: 'z001', size: 'M', color: products[0].colors[0], qty: 3 }, { id: 'z002', size: 'M', color: products[1].colors[0], qty: 1 },
    { id: products[2].id, size: 'M', color: products[2].colors[0], qty: 9 }, { id: 'z003', size: 'XXL', color: products[2].colors[0], qty: 1 }, { id: 'nope', size: 'M', color: 'sky', qty: 1 }];
  const r = api.reconcileCart(cart, products);
  assert.equal(r.cart.length, 2); assert.equal(r.cart[0].id, products[0].id); assert.equal(r.cart[1].qty, 2); assert.ok(r.notices.length >= 3);
});
test('reconcileWish(): legacy ids mapped, unknown dropped, no duplicates', () => {
  const { api } = load(); const products = dbRows.map(api.shape);
  assert.deepEqual(api.reconcileWish(['z001', products[0].id, 'zzz'], products), [products[0].id]);
});
test('totals(): free shipping at and above the threshold, fee below', () => {
  const { api } = load(); const mk = (price) => [{ id: 'a', price }]; const S = { freeShipFrom: 4000, shipFee: 250 };
  const t = (price, qty = 1) => api.totals([{ id: 'a', qty }], mk(price), S);
  assert.equal(t(3999).ship, 250); assert.equal(t(4000).ship, 0); assert.equal(t(1999, 2).ship, 250); assert.equal(t(2000, 2).ship, 0);
  assert.deepEqual(api.totals([], [], S), { sub: 0, ship: 0, total: 0 });
});
test('placeOrder(): sends ids/qty/variant only, no prices; same cart+details reuse the key, changes make a new one', async () => {
  const bodies = [];
  const { api, store } = load({ fetchImpl: async (url, init) => { bodies.push(JSON.parse(init.body)); return new Response(JSON.stringify({ message: 'x' }), { status: 503 }); } });
  const cart = [{ id: 'p1', size: 'M', color: 'sky', qty: 2, price: 1, total: 1 }]; const c = { name: 'A B', phone: '0300 1234567', address: 'House 1 Street 2', city: 'FSD', notes: '' };
  await assert.rejects(api.placeOrder(cart, c, '')); await assert.rejects(api.placeOrder(cart, c, ''));
  assert.equal(bodies[0].idempotency_key, bodies[1].idempotency_key);
  assert.deepEqual(Object.keys(bodies[0].items[0]).sort(), ['color', 'product_id', 'quantity', 'size']); assert.ok(!JSON.stringify(bodies[0]).includes('price'));
  await assert.rejects(api.placeOrder(cart, { ...c, phone: '0301 1111111' }, '')); assert.notEqual(bodies[2].idempotency_key, bodies[0].idempotency_key);
  assert.ok(store.has('zirwa_checkout_key'));
});
test('placeOrder(): success stores the confirmation and clears the key; double submit is blocked', async () => {
  let release; const gate = new Promise((r) => { release = r; });
  const order = { order_number: 'ZRW-1', items: [], total_pkr: 1 };
  const { api, store } = load({ fetchImpl: async () => { await gate; return new Response(JSON.stringify(order), { status: 201 }); } });
  const cart = [{ id: 'p1', size: 'M', color: 'sky', qty: 1 }]; const c = { name: 'A B', phone: '0300 1234567', address: 'House 1 Street 2', city: 'FSD' };
  const first = api.placeOrder(cart, c, ''); await assert.rejects(api.placeOrder(cart, c, ''), (e) => /already being placed/.test(e.message));
  release(); assert.equal((await first).order_number, 'ZRW-1');
  assert.equal(api.lastOrder().order_number, 'ZRW-1'); assert.ok(!store.has('zirwa_checkout_key'));
});
test('server validation errors surface field messages', async () => {
  const { api } = load({ fetchImpl: async () => new Response(JSON.stringify({ error: 'validation', fields: { phone: 'bad phone' } }), { status: 422 }) });
  await assert.rejects(api.placeOrder([{ id: 'p', size: '', color: '', qty: 1 }], { name: 'A B', phone: 'x', address: 'y'.repeat(12), city: 'c' }, ''), (e) => e.fields.phone === 'bad phone' && e.status === 422);
});
test('orderMessage(): built from the saved order', () => {
  const { api } = load(); const m = api.orderMessage({ order_number: 'ZRW-9', total_pkr: 4299, items: [{ name: 'Dress', size: 'M', color: 'sky', quantity: 1, line_total_pkr: 4299 }] }, (k) => 'Sky Blue');
  assert.match(m, /ZRW-9/); assert.match(m, /Dress \(Size M, Sky Blue\) x1 = PKR 4,299/); assert.match(m, /Cash on Delivery/);
});
test('no secret-looking values in any browser-facing file', () => {
  for (const f of ['public/js/config.js', 'public/js/zirwa-api.js', 'public/script.js', 'public/admin/admin.js', 'public/admin/index.html']) {
    const t = readFileSync(new URL('../' + f, import.meta.url), 'utf8');
    assert.ok(!/service_role|SERVICE_ROLE|RESEND_API_KEY|re_[A-Za-z0-9]{20,}|eyJ[A-Za-z0-9_-]{30,}/.test(t), f);
  }
});
