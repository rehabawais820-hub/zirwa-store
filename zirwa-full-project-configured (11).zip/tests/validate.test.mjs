import test from 'node:test';
import assert from 'node:assert/strict';
import { validateOrder, normalizePkPhone } from '../netlify/lib/validate.mjs';

const KEY = '11111111-1111-4111-8111-111111111111';
const PID = '22222222-2222-4222-8222-222222222222';
const good = () => ({ idempotency_key: KEY, customer: { name: 'Ayesha Khan', phone: '0300 1234567', address: 'House 12, Street 4, Peoples Colony', city: 'Faisalabad' }, items: [{ product_id: PID, quantity: 2, size: 'M', color: 'Black' }] });

test('phone formats normalise to +923XXXXXXXXX', () => {
  for (const p of ['03001234567', '0300-1234567', '+92 300 1234567', '923001234567', '00923001234567', '3001234567'])
    assert.equal(normalizePkPhone(p), '+923001234567', p);
});
test('bad phones rejected', () => {
  for (const p of ['', '12345', '0200123456', '03001234', 'abcdefghijk', '+1 202 555 0100']) assert.equal(normalizePkPhone(p), null, p);
});
test('valid order passes', () => { const r = validateOrder(good()); assert.ok(r.ok); assert.equal(r.value.phone, '+923001234567'); });
test('tampered price/total/status fields are dropped, never forwarded', () => {
  const b = good(); b.total = 1; b.shipping = 0; b.payment_status = 'paid'; b.order_status = 'delivered'; b.items[0].price = 1; b.items[0].discount_percent = 99; b.customer.total = 5;
  const r = validateOrder(b); assert.ok(r.ok);
  const s = JSON.stringify(r.value);
  for (const bad of ['price', 'total', 'shipping', 'payment_status', 'order_status', 'discount']) assert.ok(!s.includes(bad), bad);
});
test('invalid input is rejected with field errors', () => {
  const cases = [
    (b) => { b.customer.name = 'A'; }, (b) => { b.customer.phone = '123'; }, (b) => { b.customer.address = 'short'; },
    (b) => { b.customer.city = ''; }, (b) => { b.items = []; }, (b) => { b.items[0].quantity = 0; }, (b) => { b.items[0].quantity = 11; },
    (b) => { b.items[0].quantity = 1.5; }, (b) => { b.items[0].quantity = '2'; }, (b) => { b.items[0].product_id = 'not-a-uuid'; },
    (b) => { b.idempotency_key = 'abc'; }, (b) => { b.customer.notes = 'x'.repeat(301); },
  ];
  for (const mutate of cases) { const b = good(); mutate(b); assert.equal(validateOrder(b).ok, false); }
  assert.equal(validateOrder(null).ok, false); assert.equal(validateOrder([]).ok, false);
});
test('control characters are stripped', () => { const b = good(); b.customer.name = 'Ayesha\u0000 \u0007Khan'; assert.equal(validateOrder(b).value.name, 'Ayesha Khan'); });
