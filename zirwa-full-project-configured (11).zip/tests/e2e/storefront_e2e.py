import urllib.parse
"""Real-browser (Chromium) test of the storefront against the MOCK backend (tests/e2e/mock-server.mjs).
Run:  node tests/e2e/mock-server.mjs &   then   python3 tests/e2e/storefront_e2e.py
"""
import json, sys, urllib.request
from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:8799"
results = []
def check(name, cond, extra=""):
    results.append((name, bool(cond), extra)); print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if (extra and not cond) else ""))
def state(): return json.load(urllib.request.urlopen(BASE + "/__test/state"))
def reset(): urllib.request.urlopen(BASE + "/__test/reset")
def setp(obj):
    req = urllib.request.Request(BASE + "/__test/set", data=json.dumps(obj).encode(), headers={"content-type": "application/json"}); urllib.request.urlopen(req)

PNG = bytes.fromhex("89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6360000002000001e221bc330000000049454e44ae426082")

def new_page(browser, w=1280, h=900, errors=None):
    ctx = browser.new_context(viewport={"width": w, "height": h})
    pg = ctx.new_page()
    pg.route("**/fonts.googleapis.com/**", lambda r: r.fulfill(status=200, body="", content_type="text/css"))
    pg.route("**/fonts.gstatic.com/**", lambda r: r.abort())
    pg.route("https://img.example.test/**", lambda r: r.fulfill(status=200, body=PNG, content_type="image/png"))
    if errors is not None:
        pg.on("pageerror", lambda e: errors.append("pageerror: " + str(e)))
        pg.on("console", lambda m: errors.append("console: " + m.text) if m.type == "error" and "favicon" not in m.text else None)
    return ctx, pg

def fill_checkout(pg, name="Ayesha Khan", phone="0331 7756688", city="Faisalabad", addr="House 12, Street 4, Peoples Colony", note=""):
    pg.fill("#c-name", name); pg.fill("#c-phone", phone); pg.fill("#c-city", city); pg.fill("#c-addr", addr); pg.fill("#c-note", note)

def add_first_of(pg, query):
    """open shop filtered by query, quick-add first result in size M"""
    pg.goto(f"{BASE}/shop.html?q={query}"); pg.wait_for_selector(".card")
    pg.click(".card [data-add]"); pg.click("#qa-sizes .chip >> nth=2"); pg.click("#qa-add")

with sync_playwright() as p:
    browser = p.chromium.launch()
    reset()

    # ---------- HOME ----------
    errs = []; ctx, pg = new_page(browser, errors=errs)
    pg.goto(BASE + "/index.html"); pg.wait_for_selector("#best-grid .card")
    check("home: category tiles render (5)", pg.locator("#cat-row .cat").count() == 5)
    check("home: best sellers render (4)", pg.locator("#best-grid .card").count() == 4)
    check("home: decorative illustrations still render (4)", pg.locator("[data-art] svg").count() == 4, str(pg.locator("[data-art] svg").count()))
    check("home: payment copy no longer advertises JazzCash/Easypaisa", "JazzCash" not in pg.content())
    check("home: no JS errors", not errs, "; ".join(errs))
    ctx.close()

    # ---------- SHOP ----------
    errs = []; ctx, pg = new_page(browser, errors=errs)
    pg.goto(BASE + "/shop.html"); pg.wait_for_selector(".card")
    check("shop: all 54 original products load", pg.locator("#shop-grid .card").count() == 54, str(pg.locator("#shop-grid .card").count()))
    check("shop: count label", "54 products" in pg.inner_text("#count"))
    pg.check("input[name=cat][value=coords]"); check("shop: category filter co-ords = 10", pg.locator("#shop-grid .card").count() == 10)
    pg.check("input[name=cat][value=abayas]"); check("shop: abayas = 8", pg.locator("#shop-grid .card").count() == 8)
    pg.check("input[name=cat][value=new]"); check("shop: new arrivals = 21", pg.locator("#shop-grid .card").count() == 21, str(pg.locator("#shop-grid .card").count()))
    pg.goto(BASE + "/shop.html?q=abaya"); pg.wait_for_selector(".card"); check("shop: search 'abaya' finds the 8 abayas", pg.locator("#shop-grid .card").count() == 8)
    pg.goto(BASE + "/shop.html"); pg.wait_for_selector(".card"); pg.select_option("#sort", "low")
    prices = [int("".join(c for c in t.split("PKR")[1].split("PKR")[0] if c.isdigit())) for t in pg.locator("#shop-grid .card .price").all_inner_texts()]
    check("shop: sort low->high works", prices == sorted(prices) and prices[0] == 1499, str(prices[:5]))
    pg.evaluate("(() => { const r = document.querySelector('#f-range'); r.value = 2000; r.dispatchEvent(new Event('input')); })()")
    n = pg.locator("#shop-grid .card").count(); check("shop: price-up-to filter reduces list", 0 < n < 54, str(n))
    check("shop: no JS errors", not errs, "; ".join(errs)); ctx.close()

    # ---------- PRODUCT PAGE ----------
    errs = []; ctx, pg = new_page(browser, errors=errs)
    pg.goto(BASE + "/product.html?id=rosewood-embroidered-dress"); pg.wait_for_selector(".pd-info h1")
    check("product: opens by slug", pg.inner_text(".pd-info h1") == "Rosewood Embroidered Dress")
    check("product: sale shows regular price struck through", "4,299" in pg.inner_text(".pd-price") and "5,400" in pg.inner_text(".pd-price s"))
    pg.click("#add"); check("product: size required toast", "size" in pg.inner_text("#toast").lower())
    pg.click("#sizes .chip >> nth=2"); pg.click("#add"); check("product: add to cart badge = 1", pg.inner_text("#cart-badge") == "1")
    pg.goto(BASE + "/product.html?id=z001"); pg.wait_for_selector(".pd-info h1"); check("product: old ?id=z001 link still works", pg.inner_text(".pd-info h1") == "Rosewood Embroidered Dress")
    pg.goto(BASE + "/product.html?id=missing"); pg.wait_for_selector("#pd .empty"); check("product: unknown id shows 'Product not found'", "not found" in pg.inner_text("#pd").lower())
    check("product: no JS errors", not errs, "; ".join(errs)); ctx.close()

    # ---------- OLD CART MIGRATION ----------
    ctx, pg = new_page(browser)
    pg.goto(BASE + "/about.html")
    pg.evaluate("""localStorage.setItem('zirwa_cart', JSON.stringify([{id:'z001',size:'M',color:'sky',qty:2},{id:'z999',size:'M',color:'sky',qty:1}])); localStorage.setItem('zirwa_wish', JSON.stringify(['z002']))""")
    pg.goto(BASE + "/cart.html"); pg.wait_for_selector(".line")
    check("cart: old cart (z001) migrated, unknown item removed with notice", pg.locator(".line").count() == 1 and "no longer available" in pg.inner_text(".notice"))
    check("cart: wishlist migrated to new ids", json.loads(pg.evaluate("localStorage.getItem('zirwa_wish')"))[0].startswith("10000000"))
    ctx.close()

    # ---------- CHECKOUT: validation, success, totals, email ----------
    reset(); errs = []; ctx, pg = new_page(browser, errors=errs)
    pg.goto(BASE + "/shop.html?q=Rosewood"); pg.wait_for_selector(".card"); pg.click(".card [data-add]"); pg.click("#qa-sizes .chip >> nth=1"); pg.click("#qa-add")
    pg.goto(BASE + "/cart.html"); pg.wait_for_selector("#co")
    check("cart: only COD selectable, others disabled", pg.locator("input[name=pay]:not([disabled])").count() == 1 and pg.locator("input[name=pay][disabled]").count() == 3)
    check("cart: free shipping shown for a PKR 4,299 cart (threshold 4,000)", "Free" in pg.inner_text(".panel"))
    fill_checkout(pg, phone="123"); pg.click("#co-submit"); check("checkout: invalid phone blocked, no order created", "valid mobile" in pg.inner_text("#co-err") and len(state()["orders"]) == 0)
    fill_checkout(pg, addr="short"); pg.click("#co-submit"); check("checkout: short address blocked", "address" in pg.inner_text("#co-err").lower() and len(state()["orders"]) == 0)
    fill_checkout(pg, note="Please call before delivery"); pg.click("#co-submit"); pg.wait_for_url("**/order-confirmation.html")
    st = state(); o = st["orders"][0]
    check("checkout: exactly one order saved", len(st["orders"]) == 1)
    check("checkout: server price used (4,299, free shipping, COD, unpaid)", o["total_pkr"] == 4299 and o["shipping_pkr"] == 0 and o["payment_method"] == "COD" and o["payment_status"] == "unpaid", str(o["total_pkr"]))
    check("checkout: phone normalised to +92", o["customer_phone"] == "+923317756688", o["customer_phone"])
    pg.wait_for_selector(".order-no")
    check("confirmation: shows order number, COD, total", o["order_number"] in pg.inner_text(".order-no") and "Cash on Delivery" in pg.inner_text("#confirm-box") and "4,299" in pg.inner_text(".sum-total"))
    wa = pg.get_attribute(".btn-wa", "href"); check("confirmation: WhatsApp link built from saved order", wa.startswith("https://wa.me/923317756688?text=") and o["order_number"] in urllib.parse.unquote(wa))
    check("confirmation: cart emptied after order", pg.inner_text("#cart-badge") == "")
    em = state()["emails"]; body = json.dumps(em)
    check("email: sent once to owner with order number and admin link", len(em) == 1 and o["order_number"] in body and "/admin/#/orders/" in body)
    check("email: contains NO customer name/phone/address", not any(x in body for x in ["Ayesha", "7756688", "Peoples Colony"]))
    check("order: notification marked sent", state()["orders"][0]["notification_status"] == "sent")
    check("checkout: no JS errors", not errs, "; ".join(errs)); ctx.close()

    # ---------- shipping below threshold ----------
    reset(); ctx, pg = new_page(browser)
    pg.goto(BASE + "/shop.html?q=Palazzo"); pg.wait_for_selector(".card"); pg.click(".card [data-add]"); pg.click("#qa-sizes .chip >> nth=1"); pg.click("#qa-add")
    pg.goto(BASE + "/cart.html"); pg.wait_for_selector("#co"); fill_checkout(pg); pg.click("#co-submit"); pg.wait_for_url("**/order-confirmation.html")
    o = state()["orders"][0]; check("shipping: PKR 250 added below threshold, total = items + 250", o["shipping_pkr"] == 250 and o["total_pkr"] == o["subtotal_pkr"] - o["discount_pkr"] + 250, str(o))
    ctx.close()

    # ---------- double click / duplicate ----------
    reset(); ctx, pg = new_page(browser)
    add_first_of(pg, "Rosewood"); pg.goto(BASE + "/cart.html"); pg.wait_for_selector("#co"); fill_checkout(pg)
    pg.evaluate("document.querySelector('#co').dispatchEvent(new Event('submit', {cancelable:true})); document.querySelector('#co').dispatchEvent(new Event('submit', {cancelable:true}));")
    pg.wait_for_url("**/order-confirmation.html"); check("duplicate: double submit creates ONE order", len(state()["orders"]) == 1, str(len(state()["orders"])))
    ctx.close()

    # ---------- tampered request ----------
    reset(); ctx, pg = new_page(browser); pg.goto(BASE + "/index.html"); pg.wait_for_selector(".card")
    pid = state()["products"][0]["id"]
    r = pg.evaluate("""async (pid) => { const r = await fetch('/api/create-order', {method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({idempotency_key:'11111111-1111-4111-8111-111111111111', customer:{name:'Hacker One', phone:'03001234567', address:'Some long street address', city:'Lahore'}, items:[{product_id:pid, quantity:1, size:'M', color:'sky', price:1, unit_price:1}], total:1, shipping:0, payment_status:'paid', order_status:'delivered'})}); return [r.status, await r.json()]; }""", pid)
    o = state()["orders"][0]; check("tamper: price/total/status in request are ignored", r[0] == 201 and o["total_pkr"] == 4299 and o["payment_status"] == "unpaid" and o["order_status"] == "new", str(r))
    r2 = pg.evaluate("""async () => { const r = await fetch('/api/create-order', {method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({idempotency_key:'22222222-2222-4222-8222-222222222222', website:'http://spam', customer:{}, items:[]})}); return r.status; }""")
    check("abuse: honeypot rejected", r2 == 400)
    r3 = pg.evaluate("""async () => { const r = await fetch('/api/create-order', {method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({idempotency_key:'33333333-3333-4333-8333-333333333333', customer:{name:'A', phone:'1', address:'x', city:''}, items:[{product_id:'bad', quantity:99}]})}); return [r.status, Object.keys((await r.json()).fields)]; }""")
    check("invalid input rejected with field errors, nothing saved", r3[0] == 422 and len(state()["orders"]) == 1, str(r3))
    ctx.close()

    # ---------- rate limit ----------
    reset(); ctx, pg = new_page(browser); pg.goto(BASE + "/index.html"); pg.wait_for_selector(".card"); pid = state()["products"][0]["id"]
    codes = pg.evaluate("""async (pid) => { const out = []; for (let i = 0; i < 7; i++) { const k = `aaaaaaaa-aaaa-4aaa-8aaa-${String(i).padStart(12,'0')}`; const r = await fetch('/api/create-order', {method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({idempotency_key:k, customer:{name:'Rate Test', phone:'03001234567', address:'Some long street address', city:'Lahore'}, items:[{product_id:pid, quantity:1, size:'M', color:'sky'}]})}); out.push(r.status); } return out; }""", pid)
    check("rate limit: orders beyond 5 from one connection are refused (429)", codes[:5] == [201]*5 and codes[5] == 429, str(codes)); ctx.close()

    # ---------- out of stock ----------
    reset(); ctx, pg = new_page(browser)
    add_first_of(pg, "Rosewood"); pg.goto(BASE + "/cart.html"); pg.wait_for_selector("#co"); fill_checkout(pg)
    setp({"products": {"rosewood-embroidered-dress": {"stock": 0}}}); pg.click("#co-submit"); pg.wait_for_selector(".notice")
    check("out of stock: order refused, nothing saved, customer sees message and cart is refreshed", len(state()["orders"]) == 0 and "sold out" in pg.inner_text("#cart-box").lower(), pg.inner_text("#cart-box")[:150]); ctx.close()

    # ---------- email failure ----------
    reset(); setp({"emailFail": True}); errs = []; ctx, pg = new_page(browser, errors=errs)
    add_first_of(pg, "Rosewood"); pg.goto(BASE + "/cart.html"); pg.wait_for_selector("#co"); fill_checkout(pg); pg.click("#co-submit"); pg.wait_for_url("**/order-confirmation.html")
    o = state()["orders"][0]; check("email failure: order kept + customer still sees confirmation", len(state()["orders"]) == 1 and o["order_number"] in pg.inner_text(".order-no"))
    check("email failure: recorded as failed for retry", o["notification_status"] == "failed" and o["notification_attempts"] == 1, str(o.get("notification_status"))); ctx.close()

    # ---------- uploaded photos + sold-out display ----------
    reset(); ctx, pg = new_page(browser)
    setp({"products": {"rosewood-embroidered-dress": {"images": ["https://img.example.test/a.png", "https://img.example.test/b.png"]}, "mehr-lawn-frock": {"stock": 0}}})
    pg.goto(BASE + "/shop.html?q=Rosewood"); pg.wait_for_selector(".card")
    check("photos: card shows uploaded photo instead of illustration", pg.locator(".card-img img").count() == 1 and pg.locator(".card-img svg").count() == 0)
    pg.goto(BASE + "/product.html?id=rosewood-embroidered-dress"); pg.wait_for_selector(".pd-main img")
    check("photos: product page gallery shows photos with thumbnails", pg.locator(".pd-main img").count() == 1 and pg.locator("#thumbs button img").count() == 2)
    pg.click("#thumbs button >> nth=1"); check("photos: thumbnail switches main photo", "b.png" in pg.get_attribute(".pd-main img", "src"))
    pg.goto(BASE + "/shop.html?q=Mehr"); pg.wait_for_selector(".card")
    check("sold out: card tagged and button disabled", "Sold out" in pg.inner_text(".card") and pg.locator(".card button[disabled]").count() == 1)
    pg.goto(BASE + "/product.html?id=mehr-lawn-frock"); pg.wait_for_selector(".pd-info h1"); check("sold out: product page has no add-to-cart", pg.locator("#add").count() == 0 and "Sold out" in pg.inner_text(".pd-actions")); ctx.close()

    # ---------- confirmation without an order ----------
    ctx, pg = new_page(browser); pg.goto(BASE + "/order-confirmation.html"); pg.wait_for_selector(".confirm")
    check("confirmation: friendly page when opened with no order", "Thank you" in pg.inner_text(".confirm")); ctx.close()

    # ---------- backend down ----------
    ctx, pg = new_page(browser)
    pg.route("**/rest/v1/products*", lambda r: r.abort()); pg.goto(BASE + "/shop.html"); pg.wait_for_selector("#retry-load")
    check("backend down: friendly message with retry (no blank page)", "could not load" in pg.inner_text("#shop-grid").lower()); ctx.close()

    # ---------- mobile layout (375px) ----------
    reset(); errs = []; ctx, pg = new_page(browser, 375, 800, errs)
    for page in ["index.html", "shop.html", "product.html?id=rosewood-embroidered-dress", "cart.html", "about.html", "contact.html", "policies.html", "order-confirmation.html"]:
        pg.goto(f"{BASE}/{page}"); pg.wait_for_timeout(500)
        ow = pg.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
        check(f"mobile 375px: no horizontal overflow on {page}", ow <= 1, f"overflow {ow}px")
    pg.goto(BASE + "/index.html"); pg.wait_for_selector("#best-grid .card"); check("mobile: menu button visible", pg.is_visible("#menu-btn"))
    add_first_of(pg, "Rosewood"); pg.goto(BASE + "/cart.html"); pg.wait_for_selector("#co"); pg.screenshot(path="/tmp/mobile-cart.png", full_page=True)
    check("mobile: no JS errors", not errs, "; ".join(errs)); ctx.close()

    browser.close()

failed = [r for r in results if not r[1]]
print(f"\n{len(results) - len(failed)}/{len(results)} passed"); sys.exit(1 if failed else 0)
