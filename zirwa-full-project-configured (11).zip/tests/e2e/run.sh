#!/bin/sh
# Starts the mock backend, runs the browser tests, stops the server. Needs: node 20+, python3 + playwright + chromium.
cd "$(dirname "$0")/../.."
node tests/e2e/mock-server.mjs > /tmp/zirwa-mock.log 2>&1 &
SERVER=$!
sleep 1.5
FAIL=0
for t in "$@"; do python3 "tests/e2e/$t" || FAIL=1; done
kill $SERVER 2>/dev/null
exit $FAIL
