// TEST-ONLY local server: serves the real site files, a MOCK of the Supabase REST API, and runs the REAL
// Netlify function code (create-order, retry-notification). The SQL itself is NOT exercised here
// (no Postgres in the test sandbox): place_order below is a JS re-implementation used only to drive the UI.
import http from 'node:http';
import { readFileSync, existsSync, statSync } from 'node:fs';
import { join, extname } from 'node:path';
import { fileURLToPath } from 'node:url';
import createOrder from '../../netlify/functions/create-order.mjs';
import retryNotification from '../../netlify/functions/retry-notification.mjs';

const ROOT = join(fileURLToPath(new URL('../../public', import.meta.url)));
const PORT = Number(process.env.PORT || 8799), ORIGIN = `http://127.0.0.1:${PORT}`;
const demo = JSON.parse(readFileSync(new URL('../../data/demo-products.json', import.meta.url), 'utf8'));
const OWNER_TOKEN = 'owner-token', OTHER_TOKEN = 'other-token';

process.env.SUPABASE_URL = ORIGIN; process.env.SUPABASE_SERVICE_ROLE_KEY = 'test-service-secret';
process.env.RESEND_API_KEY = 're_test_key'; process.env.OWNER_EMAIL = 'owner@example.com'; process.env.EMAIL_FROM = 'Zirwa <orders@example.com>';
process.env.SITE_URL = ORIGIN; process.env.IP_HASH_SALT = 'salt';

let S;
function reset() {
  S = { products: demo.map((r, i) => ({ id: `10000000-0000-4000-8000-${String(i + 1).padStart(12, '0')}`, discount_percent: 0, created_at: new Date(2026, 0, 1, 0, 0, i).toISOString(), ...r, images: [...r.images] })),
    settings: [{ key: 'free_shipping_threshold', value: '4000' }, { key: 'shipping_fee', value: '250' }], orders: [], emails: [], emailFail: false, seq: 1000 };
}
reset();

// intercept outgoing email to Resend
const realFetch = globalThis.fetch;
globalThis.fetch = async (url, init) => {
  if (String(url).startsWith('https://api.resend.com')) { if (S.emailFail) return new Response('fail', { status: 500 }); S.emails.push(JSON.parse(init.body)); return new Response('{"id":"1"}'); }
  return realFetch(url, init);
};

function placeOrder(a) {
  const ex = S.orders.find((o) => o.idempotency_key === a.p_idempotency_key);
  const out = (o, dup) => ({ duplicate: dup, order_id: o.id, order_number: o.order_number, subtotal_pkr: o.subtotal_pkr, discount_pkr: o.discount_pkr, shipping_pkr: o.shipping_pkr, total_pkr: o.total_pkr, payment_method: 'COD', payment_status: 'unpaid', items: o.items.map(({ name, size, color, quantity, unit_price_pkr, line_total_pkr }) => ({ name, size, color, quantity, unit_price_pkr, line_total_pkr })) });
  if (ex) return out(ex, true);
  const recent = S.orders.filter((o) => o.client_hash === a.p_client_hash).length; if (recent >= 5) throw new Error('rate_limited');
  const staged = []; let sub = 0, disc = 0;
  const stock = new Map(S.products.map((p) => [p.id, p.stock]));
  for (const it of a.p_items) {
    const p = S.products.find((x) => x.id === it.product_id); if (!p || !p.is_active) throw new Error('product_unavailable');
    if (p.sizes.length ? !p.sizes.includes(it.size) : it.size) throw new Error('invalid_variant');
    if (p.colors.length ? !p.colors.includes(it.color) : it.color) throw new Error('invalid_variant');
    if (stock.get(p.id) < it.quantity) throw new Error('out_of_stock'); stock.set(p.id, stock.get(p.id) - it.quantity);
    const final = p.sale_price_pkr ?? p.price_pkr; sub += p.price_pkr * it.quantity; disc += (p.price_pkr - final) * it.quantity;
    staged.push({ product_id: p.id, name: p.name, size: it.size, color: it.color, quantity: it.quantity, unit_price_pkr: final, line_total_pkr: final * it.quantity });
  }
  S.products.forEach((p) => { p.stock = stock.get(p.id); });
  const th = Number(S.settings[0].value), fee = Number(S.settings[1].value), ship = sub - disc >= th ? 0 : fee;
  const o = { id: `20000000-0000-4000-8000-${String(S.orders.length + 1).padStart(12, '0')}`, order_number: `ZRW-TEST-${++S.seq}`, idempotency_key: a.p_idempotency_key, customer_name: a.p_customer_name, customer_phone: a.p_phone, delivery_address: a.p_address, city: a.p_city, notes: a.p_notes,
    subtotal_pkr: sub, discount_pkr: disc, shipping_pkr: ship, total_pkr: sub - disc + ship, payment_method: 'COD', payment_status: 'unpaid', order_status: 'new', client_hash: a.p_client_hash, notification_status: 'pending', notification_attempts: 0, items: staged, created_at: new Date().toISOString() };
  S.orders.push(o); return out(o, false);
}

const toml = readFileSync(new URL('../../netlify.toml', import.meta.url), 'utf8');
const adminCsp = /for = "\/admin\/\*"[\s\S]*?Content-Security-Policy = "([^"]+)"/.exec(toml)[1];
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.xml': 'application/xml', '.txt': 'text/plain' };
const send = (res, code, body, type = 'application/json') => { res.writeHead(code, { 'content-type': type }); res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body)); };
const toReq = async (req) => { const chunks = []; for await (const c of req) chunks.push(c); return new Request(ORIGIN + req.url, { method: req.method, headers: req.headers, body: ['GET', 'HEAD'].includes(req.method) ? undefined : Buffer.concat(chunks) }); };
const sendResp = async (res, r) => { const t = await r.text(); res.writeHead(r.status, Object.fromEntries(r.headers)); res.end(t); };
const bearer = (req) => (req.headers.authorization || '').replace(/^Bearer\s+/i, '');

http.createServer(async (req, res) => {
  const url = new URL(req.url, ORIGIN), path = url.pathname;
  try {
    if (path === '/js/config.js') return send(res, 200, `window.ZIRWA_CONFIG={SUPABASE_URL:'${ORIGIN}',SUPABASE_ANON_KEY:'test-anon-key'};`, 'text/javascript');
    if (path === '/__test/reset') { reset(); return send(res, 200, { ok: 1 }); }
    if (path === '/__test/state') return send(res, 200, S);
    if (path === '/__test/set') { const b = JSON.parse(await (await toReq(req)).text()); if ('emailFail' in b) S.emailFail = b.emailFail; for (const [slug, patch] of Object.entries(b.products || {})) Object.assign(S.products.find((p) => p.slug === slug), patch); return send(res, 200, { ok: 1 }); }
    if (path === '/api/create-order') return sendResp(res, await createOrder(await toReq(req), { ip: req.headers['x-test-ip'] || '203.0.113.5' }));
    if (path === '/api/retry-notification') return sendResp(res, await retryNotification(await toReq(req)));
    if (path === '/auth/v1/user') { const t = bearer(req); return t === OWNER_TOKEN ? send(res, 200, { id: 'owner-1' }) : t === OTHER_TOKEN ? send(res, 200, { id: 'other-2' }) : send(res, 401, {}); }
    if (path === '/rest/v1/admins') return send(res, 200, url.searchParams.get('user_id') === 'eq.owner-1' ? [{ user_id: 'owner-1' }] : []);
    if (path === '/rest/v1/products') { if (bearer(req) === 'test-service-secret') return send(res, 200, S.products); return send(res, 200, S.products.filter((p) => p.is_active).sort((a, b) => a.created_at.localeCompare(b.created_at) || a.slug.localeCompare(b.slug))); }
    if (path === '/rest/v1/settings') return send(res, 200, S.settings);
    if (path === '/rest/v1/rpc/place_order') { const a = JSON.parse(await (await toReq(req)).text()); try { return send(res, 200, placeOrder(a)); } catch (e) { return send(res, 400, { message: e.message, code: 'P0001' }); } }
    if (path === '/rest/v1/orders') {
      if (req.method === 'PATCH') { const id = (url.searchParams.get('id') || '').replace('eq.', ''); Object.assign(S.orders.find((o) => o.id === id) || {}, JSON.parse(await (await toReq(req)).text())); res.writeHead(204); return res.end(); }
      const id = (url.searchParams.get('id') || '').replace('eq.', ''); const list = id ? S.orders.filter((o) => o.id === id) : S.orders.filter((o) => ['failed', 'pending'].includes(o.notification_status));
      return send(res, 200, list.map((o) => ({ ...o, order_items: o.items.map((i) => ({ product_name: i.name, ...i })) })));
    }
    let f = join(ROOT, path === '/' ? 'index.html' : path.endsWith('/') ? path + 'index.html' : path);
    if (!f.startsWith(ROOT) || !existsSync(f) || statSync(f).isDirectory()) return send(res, 404, 'not found', 'text/plain');
    { const headers = { 'content-type': MIME[extname(f)] || 'application/octet-stream' };
      if (path.startsWith('/admin')) Object.assign(headers, { 'content-security-policy': adminCsp, 'x-frame-options': 'DENY', 'cache-control': 'no-store' });
      res.writeHead(200, headers); res.end(readFileSync(f)); }
  } catch (e) { console.error(e); send(res, 500, { error: String(e) }); }
}).listen(PORT, () => console.log('mock ready ' + ORIGIN));
