"""Real-browser test of the admin panel UI (tests/e2e/fake-supabase.js stands in for supabase-js) plus the REAL
retry-notification function behind the mock server. Run via tests/e2e/run.sh admin_e2e.py"""
import json, sys, os, re, urllib.request
from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:8799"; HERE = os.path.dirname(os.path.abspath(__file__))
FAKE = open(os.path.join(HERE, "fake-supabase.js")).read()
results = []
def check(name, cond, extra=""):
    results.append(bool(cond)); print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if (extra and not cond) else ""))
def get(path): return json.load(urllib.request.urlopen(BASE + path))
def post(path, obj, headers=None):
    req = urllib.request.Request(BASE + path, data=json.dumps(obj).encode(), headers={"content-type": "application/json", **(headers or {})})
    try: r = urllib.request.urlopen(req); return r.status, json.load(r)
    except urllib.error.HTTPError as e: return e.code, json.loads(e.read() or b"{}")
PNG = bytes.fromhex("89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6360000002000001e221bc330000000049454e44ae426082")
import time
def wait_js(pg, expr, timeout=8.0):
    """poll from Python (Playwright's wait_for_function needs eval(), which the admin page's CSP rightly forbids)"""
    end = time.time() + timeout
    while time.time() < end:
        if pg.evaluate(expr): return True
        time.sleep(0.05)
    raise TimeoutError("condition never became true: " + expr)
def calls(pg): return pg.evaluate("window.__calls")
def try_file(pg, name, mime, buf):
    """upload one file into the open product form and return the validation message (waits for the async check)"""
    pg.evaluate("document.querySelector('#formError').textContent = ''")
    pg.set_input_files("#imageInput", {"name": name, "mimeType": mime, "buffer": buf})
    wait_js(pg, "document.querySelector('#formError').textContent.length > 0"); return pg.inner_text("#formError")

def open_admin(browser, w=1280, h=900, errors=None):
    ctx = browser.new_context(viewport={"width": w, "height": h}); pg = ctx.new_page()
    pg.route("**/cdn.jsdelivr.net/**", lambda r: r.fulfill(status=200, body=FAKE, content_type="text/javascript"))
    pg.route("https://img.example.test/**", lambda r: r.fulfill(status=200, body=PNG, content_type="image/png"))
    dialogs = []
    def on_dialog(d): dialogs.append(d.message); d.accept()
    pg.on("dialog", on_dialog)
    if errors is not None:
        pg.on("pageerror", lambda e: errors.append("pageerror: " + str(e)))
        pg.on("console", lambda m: errors.append("console: " + m.text) if m.type == "error" else None)
    return ctx, pg, dialogs

def login(pg, email, pw="right-pass"):
    pg.fill("input[name=email]", email); pg.fill("input[name=password]", pw); pg.click("#loginForm button[type=submit]")

with sync_playwright() as p:
    browser = p.chromium.launch()
    urllib.request.urlopen(BASE + "/__test/reset")

    # ---------- access control in the UI ----------
    errs = []; ctx, pg, dialogs = open_admin(browser, errors=errs)
    pg.goto(BASE + "/admin/"); pg.wait_for_selector("#loginForm")
    check("anonymous visitor: only the login form is visible", pg.is_visible("#loginForm") and not pg.is_visible("#app") and pg.locator(".item").count() == 0)
    login(pg, "owner@example.com", "wrong"); wait_js(pg, "document.querySelector('#loginError').textContent.length > 0")
    check("wrong password: error shown, still logged out", "failed" in pg.inner_text("#loginError").lower() and not pg.is_visible("#app"))
    login(pg, "other@example.com"); wait_js(pg, "document.querySelector('#loginError').textContent.includes('not the store owner')")
    check("logged-in NON-owner is rejected and signed out", not pg.is_visible("#app") and pg.evaluate("sessionStorage.getItem('fake_token')") is None)
    login(pg, "owner@example.com"); pg.wait_for_selector(".item")
    check("owner: dashboard shows all 54 demo products", pg.locator("#productList .item").count() == 54, str(pg.locator("#productList .item").count()))
    check("owner: demo products marked 'demo', 'No photo' placeholder shown", pg.locator(".badge", has_text="demo").count() == 54 and pg.locator(".thumb.none").count() == 54)
    check("CSP/headers: admin works with the real Content-Security-Policy (no console errors)", not errs, "; ".join(errs[:3]))

    # ---------- search / deactivate ----------
    pg.fill("#search", "abaya"); check("search filters products (abayas = 8)", pg.locator("#productList .item").count() == 8)
    pg.fill("#search", "Rosewood"); pg.click(".item >> text=Deactivate"); pg.wait_for_selector(".item.inactive")
    check("deactivate: sends is_active=false for that product only", any(c.get("op") == "update" and c["row"] == {"is_active": False} and c["filter"][0][0] == "id" for c in calls(pg)))
    pg.click(".item >> text=Activate"); wait_js(pg, "!document.querySelector('.item.inactive')"); pg.fill("#search", "")

    # ---------- edit: discount <-> sale price, validation ----------
    pg.fill("#search", "Rosewood"); pg.click(".item >> text=Edit"); pg.wait_for_selector("#productDialog[open]")
    check("edit: form pre-filled (regular 5400, sale 4299, 20% off)", pg.input_value("input[name=price_pkr]") == "5400" and pg.input_value("input[name=sale_price_pkr]") == "4299" and pg.input_value("input[name=discount_percent]") == "20")
    check("edit: 3 colour boxes ticked and category set", pg.locator("#colorPicker input:checked").count() == 3 and pg.input_value("#categorySelect") == "dresses")
    pg.fill("input[name=price_pkr]", "5000"); pg.fill("input[name=discount_percent]", "20"); check("discount % -> sale price (5000 @20% = 4000)", pg.input_value("input[name=sale_price_pkr]") == "4000")
    pg.fill("input[name=sale_price_pkr]", "4500"); check("sale price -> discount % (4500 of 5000 = 10%)", pg.input_value("input[name=discount_percent]") == "10")
    n = len(calls(pg)); pg.fill("input[name=sale_price_pkr]", "5000"); pg.click("#saveProduct")
    check("sale price >= regular price is refused, nothing sent", "lower than" in pg.inner_text("#formError") and len(calls(pg)) == n)
    pg.fill("input[name=sale_price_pkr]", ""); pg.fill("input[name=stock]", "7"); pg.click("#saveProduct"); wait_js(pg, "!document.querySelector('#productDialog').open")
    upd = [c for c in calls(pg) if c.get("table") == "products" and c.get("op") == "update" and "stock" in (c["row"] or {})][-1]["row"]
    check("edit save: payload has exact numbers, sale cleared, no secrets", upd["price_pkr"] == 5000 and upd["sale_price_pkr"] is None and upd["stock"] == 7 and "service" not in json.dumps(upd).lower())

    # ---------- image validation ----------
    pg.fill("#search", ""); pg.click("#addProduct"); pg.wait_for_selector("#productDialog[open]")
    check("image: PDF refused", "only JPG, PNG or WebP" in try_file(pg, "notes.pdf", "application/pdf", b"%PDF-1.4" + b"0" * 500))
    check("image: GIF refused", "only JPG, PNG or WebP" in try_file(pg, "anim.gif", "image/gif", b"GIF89a" + b"0" * 500))
    check("image: text file renamed .jpg refused (content check)", "does not match" in try_file(pg, "fake.jpg", "image/jpeg", b"this is plain text pretending to be a jpeg" * 20))
    check("image: file over 5 MB refused", "5 MB" in try_file(pg, "big.png", "image/png", PNG + b"0" * (5 * 1024 * 1024 + 10)))
    check("image: none of the bad files were queued", pg.locator("#imageList .img").count() == 0)

    # ---------- add product ----------
    pg.fill("input[name=name]", "Test Lawn Suit"); check("add: URL name (slug) auto-filled", pg.input_value("input[name=slug]") == "test-lawn-suit")
    pg.fill("textarea[name=description]", "A test product."); pg.fill("input[name=price_pkr]", "3000"); pg.fill("input[name=discount_percent]", "")
    pg.fill("input[name=sale_price_pkr]", "2500"); pg.fill("input[name=stock]", "12"); pg.select_option("#categorySelect", "tops"); pg.fill("input[name=sizes]", "S, M, M, L")
    pg.check("#colorPicker input[value=sky]"); pg.check("#colorPicker input[value=wine]"); pg.check("input[name=is_new]"); pg.check("input[name=is_bestseller]")
    pg.set_input_files("#imageInput", [{"name": "a.png", "mimeType": "image/png", "buffer": PNG + b"\0" * 400}, {"name": "b.png", "mimeType": "image/png", "buffer": PNG + b"\0" * 400}])
    wait_js(pg, "document.querySelectorAll('#imageList .img img').length === 2")
    check("image: two valid PNGs queued with previews", pg.locator("#imageList .img img").count() == 2)
    pg.click("#saveProduct"); wait_js(pg, "!document.querySelector('#productDialog').open"); c = calls(pg)
    ins = [x for x in c if x.get("table") == "products" and x.get("op") == "insert"][-1]["row"]; ups = [x for x in c if x.get("storage") == "upload"]
    check("add: insert payload correct (price, sale, stock, category, sizes de-duplicated, colours, flags, not demo)", ins["price_pkr"] == 3000 and ins["sale_price_pkr"] == 2500 and ins["stock"] == 12 and ins["category_slug"] == "tops" and ins["sizes"] == ["S", "M", "L"] and ins["colors"] == ["sky", "wine"] and ins["is_new"] and ins["is_bestseller"] and ins["is_demo"] is False and ins["is_active"], json.dumps(ins)[:300])
    check("add: 2 images uploaded to products/<id>/<uuid>.png in the product-images bucket, public URLs saved", len(ups) == 2 and all(re.fullmatch(rf"products/{ins['id']}/[0-9a-f-]{{36}}\.png", u["path"]) and u["bucket"] == "product-images" for u in ups) and len(ins["images"]) == 2)
    check("add: product appears in list (55)", pg.locator("#productList .item").count() == 55)

    # ---------- duplicate slug ----------
    pg.click("#addProduct"); pg.fill("input[name=name]", "Test Lawn Suit"); pg.fill("input[name=price_pkr]", "1000"); pg.click("#saveProduct"); wait_js(pg, "document.querySelector('#formError').textContent.length > 0")
    check("duplicate URL name refused with a clear message", "already used" in pg.inner_text("#formError")); pg.click("#cancelProduct")

    # ---------- delete (also cleans images) ----------
    pg.fill("#search", "Test Lawn"); pg.click(".item >> text=Delete"); wait_js(pg, "document.querySelectorAll('#productList .item').length === 0")
    rm = [x for x in calls(pg) if x.get("storage") == "remove"]
    check("delete: asks for confirmation, removes the row and its 2 stored images", any("permanently" in d for d in dialogs) and rm and len(rm[-1]["paths"]) == 2, str(rm))
    pg.fill("#search", ""); check("delete: list back to 54", pg.locator("#productList .item").count() == 54)
    ctx.close()

    # ---------- ORDERS tab + REAL retry function ----------
    urllib.request.urlopen(BASE + "/__test/reset")
    post("/__test/set", {"emailFail": True}); pid = get("/__test/state")["products"][0]["id"]
    st, ord_ = post("/api/create-order", {"idempotency_key": "11111111-1111-4111-8111-111111111111", "customer": {"name": "Sara Malik", "phone": "03211234567", "address": "Street 5, Madina Town, Faisalabad", "city": "Faisalabad", "notes": "Call first"}, "items": [{"product_id": pid, "quantity": 2, "size": "M", "color": "sky"}]})
    state = get("/__test/state"); oid = state["orders"][0]["id"]
    check("setup: order saved although the email failed (notification=failed)", st == 201 and state["orders"][0]["notification_status"] == "failed")
    post("/__test/set", {"emailFail": False})
    errs = []; ctx, pg, dialogs = open_admin(browser, errors=errs); pg.goto(BASE + f"/admin/#/orders/{oid}"); pg.wait_for_selector("#loginForm"); login(pg, "owner@example.com")
    pg.wait_for_selector("details.order[open]")
    check("deep link from the email opens the Orders tab with that order expanded", pg.is_visible("#tab-orders") and "Sara Malik" in pg.inner_text("details.order"))
    check("order shows items, phone, address, totals, COD/unpaid, 'email failed' badge", all(x in pg.inner_text("details.order") for x in ["Sky Blue", "+923211234567", "Madina Town", "COD · unpaid", "email failed"]))
    pg.click("text=Retry email notification"); wait_js(pg, "document.querySelector('#orderList .badge.ok')")
    check("retry: REAL retry-notification function sent the email with the owner's token", any("email sent" in d for d in dialogs) and get("/__test/state")["orders"][0]["notification_status"] == "sent" and len(get("/__test/state")["emails"]) == 1)
    pg.select_option("select[aria-label=order_status]", "confirmed"); pg.wait_for_timeout(300)
    check("order status change sends only the status field", any(c.get("table") == "orders" and c.get("op") == "update" and c["row"] == {"order_status": "confirmed"} for c in calls(pg)))
    check("orders tab: no console errors under the real CSP", not errs, "; ".join(errs[:3]))
    ctx.close()

    # ---------- retry endpoint authorization (real function) ----------
    s1, _ = post("/api/retry-notification", {"order_id": oid}); s2, _ = post("/api/retry-notification", {"order_id": oid}, {"authorization": "Bearer other-token"}); s3, _ = post("/api/retry-notification", {"order_id": oid}, {"authorization": "Bearer nonsense"})
    check("retry endpoint: no token 401, non-owner 403, bad token 401", (s1, s2, s3) == (401, 403, 401), str((s1, s2, s3)))

    # ---------- mobile ----------
    ctx, pg, _ = open_admin(browser, 375, 800); pg.goto(BASE + "/admin/"); pg.wait_for_selector("#loginForm")
    check("mobile 375px: login has no horizontal overflow", pg.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth") <= 1)
    login(pg, "owner@example.com"); pg.wait_for_selector(".item")
    check("mobile 375px: product list has no horizontal overflow", pg.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth") <= 1)
    pg.click("#addProduct"); pg.wait_for_selector("#productDialog[open]"); pg.screenshot(path="/tmp/admin-mobile-form.png")
    check("mobile 375px: product form fits the screen", pg.evaluate("(() => { const r = document.querySelector('#productDialog').getBoundingClientRect(); return r.left >= 0 && r.right <= window.innerWidth + 1; })()"))
    ctx.close(); browser.close()

print(f"\n{sum(results)}/{len(results)} passed"); sys.exit(0 if all(results) else 1)
