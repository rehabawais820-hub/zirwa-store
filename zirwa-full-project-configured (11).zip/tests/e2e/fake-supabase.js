/* TEST-ONLY stand-in for @supabase/supabase-js (the real library is loaded from a CDN in production).
   It implements just the calls admin.js makes, keeps data in memory, and records every call in window.__calls
   so tests can inspect exactly what the admin panel would send to Supabase. */
(function () {
  const calls = (window.__calls = []);
  const db = { products: null, orders: null, categories: [
    { slug: 'dresses', name: 'Dresses', position: 1 }, { slug: 'coords', name: 'Co-ords', position: 2 }, { slug: 'tops', name: 'Tops', position: 3 },
    { slug: 'bottoms', name: 'Bottoms', position: 4 }, { slug: 'abayas', name: 'Abayas', position: 5 }, { slug: 'unisex', name: 'Unisex', position: 6 }] };
  const ready = fetch('/__test/state').then((r) => r.json()).then((st) => { db.products = st.products.map((p) => ({ ...p })); db.orders = st.orders.map((o) => ({ ...o })); });
  const token = () => sessionStorage.getItem('fake_token');
  const ok = (data) => ({ data, error: null });
  const overrides = {}; // owner edits made through this fake client (status changes)
  async function freshOrders() { const st = await (await fetch('/__test/state')).json(); db.orders = st.orders.map((o) => ({ ...o, ...(overrides[o.id] || {}) })); }

  function query(table) {
    const q = { _f: [], _op: 'select', _ord: null, _lim: null, _row: null };
    const api = {
      select() { q._op = q._op === 'select' ? 'select' : q._op; return api; }, order(col, o) { q._ord = [col, o && o.ascending === false ? -1 : 1]; return api; }, limit(n) { q._lim = n; return api; },
      eq(c, v) { q._f.push([c, v]); return api; },
      insert(row) { q._op = 'insert'; q._row = row; return api; }, update(row) { q._op = 'update'; q._row = row; return api; }, delete() { q._op = 'delete'; return api; },
      then(res, rej) { return run().then(res, rej); },
    };
    async function run() {
      await ready; const rows = db[table]; const match = (r) => q._f.every(([c, v]) => r[c] === v);
      calls.push({ table, op: q._op, row: q._row, filter: q._f.slice() });
      if (q._op === 'insert') { if (table === 'products' && rows.some((r) => r.slug === q._row.slug)) return { data: null, error: { code: '23505', message: 'duplicate key' } }; rows.unshift({ created_at: new Date().toISOString(), ...q._row }); return ok(null); }
      if (q._op === 'update') { rows.filter(match).forEach((r) => { Object.assign(r, q._row); if (table === 'orders') overrides[r.id] = Object.assign(overrides[r.id] || {}, q._row); }); return ok(null); }
      if (q._op === 'delete') { db[table] = rows.filter((r) => !match(r)); return ok(null); }
      if (table === 'orders') await freshOrders();
      let out = db[table].filter(match).map((r) => ({ ...r }));
      if (q._ord) out.sort((a, b) => (a[q._ord[0]] > b[q._ord[0]] ? 1 : -1) * q._ord[1]);
      if (q._lim) out = out.slice(0, q._lim);
      if (table === 'orders') out = out.map((o) => ({ ...o, order_items: (o.items || []).map((i) => ({ product_name: i.name, ...i })) }));
      return ok(out);
    }
    return api;
  }
  window.supabase = { createClient() { return {
    auth: {
      async getSession() { const t = token(); return { data: { session: t ? { access_token: t } : null } }; },
      async signInWithPassword({ email, password }) {
        if (email === 'owner@example.com' && password === 'right-pass') { sessionStorage.setItem('fake_token', 'owner-token'); return { error: null }; }
        if (email === 'other@example.com' && password === 'right-pass') { sessionStorage.setItem('fake_token', 'other-token'); return { error: null }; }
        return { error: { message: 'Invalid login credentials' } };
      },
      async signOut() { sessionStorage.removeItem('fake_token'); return { error: null }; },
      onAuthStateChange() { return { data: { subscription: {} } }; },
    },
    async rpc(fn) { return fn === 'is_admin' ? { data: token() === 'owner-token', error: null } : { data: null, error: { message: 'unknown rpc' } }; },
    from: query,
    storage: { from(bucket) { return {
      async upload(path, file, opts) { calls.push({ storage: 'upload', bucket, path, type: file.type, size: file.size, opts }); return { error: null }; },
      getPublicUrl(path) { return { data: { publicUrl: `https://img.example.test/storage/v1/object/public/${bucket}/${path}` } }; },
      async remove(paths) { calls.push({ storage: 'remove', bucket, paths }); return { error: null }; },
    }; } },
  }; } };
})();
