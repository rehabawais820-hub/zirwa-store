import test from 'node:test';
import assert from 'node:assert/strict';
import handler from '../netlify/functions/create-order.mjs';

process.env.SUPABASE_URL = 'https://x.supabase.co'; process.env.SUPABASE_SERVICE_ROLE_KEY = 'service-secret';
process.env.RESEND_API_KEY = 're_test'; process.env.OWNER_EMAIL = 'owner@example.com'; process.env.EMAIL_FROM = 'Zirwa <orders@example.com>';
process.env.SITE_URL = 'https://zirwa.example'; process.env.IP_HASH_SALT = 'salt';

const KEY = '11111111-1111-4111-8111-111111111111', PID = '22222222-2222-4222-8222-222222222222';
const body = (o = {}) => ({ idempotency_key: KEY, customer: { name: 'Ayesha Khan', phone: '03001234567', address: 'House 12, Street 4, Peoples Colony', city: 'Faisalabad' }, items: [{ product_id: PID, quantity: 1, size: 'M', color: 'Black' }], ...o });
const dbOrder = (dup = false) => ({ duplicate: dup, order_id: '33333333-3333-4333-8333-333333333333', order_number: 'ZRW-261014-1001', subtotal_pkr: 3000, discount_pkr: 300, shipping_pkr: 250, total_pkr: 2950, payment_method: 'COD', payment_status: 'unpaid', items: [{ name: 'Rose Dress', size: 'M', color: 'Black', quantity: 1, unit_price_pkr: 2700, line_total_pkr: 2700 }] });
const req = (b, headers = {}) => new Request('https://zirwa.example/api/create-order', { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: typeof b === 'string' ? b : JSON.stringify(b) });

function mockFetch({ rpc = () => dbOrder(), emailOk = true } = {}) {
  const calls = [];
  globalThis.fetch = async (url, init) => {
    calls.push({ url: String(url), init, body: init?.body ? JSON.parse(init.body) : null });
    if (String(url).includes('/rpc/place_order')) { const r = rpc(); if (r instanceof Error) return new Response(JSON.stringify({ message: r.message, code: 'P0001' }), { status: 400 }); return new Response(JSON.stringify(r), { status: 200 }); }
    if (String(url).includes('api.resend.com')) return emailOk ? new Response('{"id":"1"}', { status: 200 }) : new Response('boom', { status: 500 });
    if (init?.method === 'PATCH') return new Response(null, { status: 204 });
    return new Response('[]', { status: 200 });
  };
  return calls;
}

test('success: saves via rpc, emails owner, marks sent, returns order number', async () => {
  const calls = mockFetch(); const res = await handler(req(body()), { ip: '1.2.3.4' });
  assert.equal(res.status, 201); const j = await res.json();
  assert.equal(j.order_number, 'ZRW-261014-1001'); assert.equal(j.payment_method, 'COD'); assert.equal(j.payment_status, 'unpaid');
  const mail = calls.find((c) => c.url.includes('resend')); assert.ok(mail);
  assert.equal(mail.init.headers.authorization, 'Bearer re_test');
  const sent = JSON.stringify(mail.body);
  assert.ok(sent.includes('ZRW-261014-1001') && sent.includes('/admin/#/orders/'));
  for (const pii of ['Ayesha', '3001234567', 'Peoples Colony']) assert.ok(!sent.includes(pii), `email must not contain ${pii}`);
  assert.equal(calls.find((c) => c.init?.method === 'PATCH').body.notification_status, 'sent');
});
test('tampered prices are never sent to the database', async () => {
  const calls = mockFetch(); const b = body({ total: 1, shipping: 0, payment_status: 'paid' }); b.items[0].price = 1; b.items[0].unit_price = 1;
  await handler(req(b), { ip: '1.2.3.4' });
  const rpc = calls.find((c) => c.url.includes('place_order')).body; const s = JSON.stringify(rpc);
  assert.deepEqual(Object.keys(rpc.p_items[0]).sort(), ['color', 'product_id', 'quantity', 'size']);
  assert.ok(!s.includes('"price') && !s.includes('paid'));
});
test('invalid input: 422 and database never called', async () => {
  const calls = mockFetch(); const b = body(); b.customer.phone = '123';
  const res = await handler(req(b), { ip: '1' }); assert.equal(res.status, 422); assert.ok((await res.json()).fields.phone); assert.equal(calls.length, 0);
});
test('bad JSON / oversized body / wrong method / honeypot / foreign origin', async () => {
  const calls = mockFetch();
  assert.equal((await handler(req('{nope'), {})).status, 400);
  assert.equal((await handler(req('x'.repeat(30000)), {})).status, 413);
  assert.equal((await handler(new Request('https://zirwa.example/api/create-order'), {})).status, 405);
  assert.equal((await handler(req(body({ website: 'http://spam' })), {})).status, 400);
  assert.equal((await handler(req(body(), { origin: 'https://evil.example' }), {})).status, 403);
  assert.equal(calls.length, 0);
});
test('duplicate submission: same order returned, no second email', async () => {
  const calls = mockFetch({ rpc: () => dbOrder(true) }); const res = await handler(req(body()), { ip: '1' });
  assert.equal(res.status, 200); assert.equal((await res.json()).duplicate, true); assert.ok(!calls.some((c) => c.url.includes('resend')));
});
test('email delivery failure: order kept, still 201, failure recorded for retry', async () => {
  const calls = mockFetch({ emailOk: false }); const res = await handler(req(body()), { ip: '1' });
  assert.equal(res.status, 201);
  const p = calls.find((c) => c.init?.method === 'PATCH').body; assert.equal(p.notification_status, 'failed'); assert.match(p.notification_error, /email_provider_500/);
});
test('missing email config: order kept, failure recorded', async () => {
  const keep = process.env.RESEND_API_KEY; delete process.env.RESEND_API_KEY; const calls = mockFetch();
  const res = await handler(req(body()), { ip: '1' }); process.env.RESEND_API_KEY = keep;
  assert.equal(res.status, 201); assert.equal(calls.find((c) => c.init?.method === 'PATCH').body.notification_status, 'failed');
});
test('database business errors map to safe messages; unknown errors leak nothing', async () => {
  for (const [msg, status] of [['rate_limited', 429], ['out_of_stock', 409], ['product_unavailable', 409], ['invalid_variant', 422]]) {
    mockFetch({ rpc: () => new Error(msg) }); assert.equal((await handler(req(body()), { ip: '1' })).status, status, msg);
  }
  mockFetch({ rpc: () => new Error('relation "orders" secret internals') });
  const res = await handler(req(body()), { ip: '1' }); assert.equal(res.status, 500);
  assert.ok(!JSON.stringify(await res.json()).includes('secret internals'));
});
