import test from 'node:test';
import assert from 'node:assert/strict';
import handler from '../netlify/functions/retry-notification.mjs';

process.env.SUPABASE_URL = 'https://x.supabase.co'; process.env.SUPABASE_SERVICE_ROLE_KEY = 'service-secret';
process.env.RESEND_API_KEY = 're_test'; process.env.OWNER_EMAIL = 'o@example.com'; process.env.EMAIL_FROM = 'Z <o@example.com>'; process.env.SITE_URL = 'https://zirwa.example';
const OID = '33333333-3333-4333-8333-333333333333';
const req = (token, body = { order_id: OID }) => new Request('https://zirwa.example/api/retry-notification', { method: 'POST', headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) }, body: JSON.stringify(body) });
const order = { id: OID, order_number: 'ZRW-1', subtotal_pkr: 1, discount_pkr: 0, shipping_pkr: 0, total_pkr: 1, payment_method: 'COD', payment_status: 'unpaid', notification_attempts: 1, order_items: [{ product_name: 'X', size: '', color: '', quantity: 1, line_total_pkr: 1 }] };
function mock({ user = { id: 'u1' }, admin = true, emailOk = true }) {
  const calls = [];
  globalThis.fetch = async (url, init) => {
    url = String(url); calls.push({ url, init });
    if (url.includes('/auth/v1/user')) return user ? new Response(JSON.stringify(user)) : new Response('{}', { status: 401 });
    if (url.includes('/rest/v1/admins')) return new Response(JSON.stringify(admin ? [{ user_id: 'u1' }] : []));
    if (url.includes('/rest/v1/orders') && init?.method === 'PATCH') return new Response(null, { status: 204 });
    if (url.includes('/rest/v1/orders')) return new Response(JSON.stringify([order]));
    if (url.includes('resend')) return emailOk ? new Response('{}') : new Response('', { status: 500 });
    return new Response('[]');
  };
  return calls;
}
test('no token -> 401, nothing sent', async () => { const c = mock({}); assert.equal((await handler(req(null))).status, 401); assert.equal(c.length, 0); });
test('invalid token -> 401', async () => { mock({ user: null }); assert.equal((await handler(req('bad'))).status, 401); });
test('logged-in non-owner -> 403, no email', async () => { const c = mock({ admin: false }); assert.equal((await handler(req('t'))).status, 403); assert.ok(!c.some((x) => x.url.includes('resend'))); });
test('owner retry succeeds and marks sent', async () => {
  const c = mock({}); const r = await handler(req('t')); assert.equal(r.status, 200); assert.equal((await r.json()).results[0].sent, true);
  const p = c.find((x) => x.init?.method === 'PATCH'); assert.equal(JSON.parse(p.init.body).notification_attempts, 2);
});
test('owner retry still failing stays failed (no crash)', async () => { mock({ emailOk: false }); const r = await handler(req('t')); assert.equal((await r.json()).results[0].sent, false); });
test('malformed order id -> 404', async () => { mock({}); assert.equal((await handler(req('t', { order_id: "x' or 1=1" }))).status, 404); });
