import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { extractOriginalProducts, toRows, CATEGORY_SLUGS, COLOR_KEYS } from '../scripts/extract-demo-products.mjs';
import { buildSeedSql } from '../scripts/seed-sql.mjs';

const original = extractOriginalProducts();
const rows = toRows(original);

test('exactly the 54 original products are extracted, with the original category counts', () => {
  assert.equal(rows.length, 54);
  const by = {}; rows.forEach((r) => { by[r.category_slug] = (by[r.category_slug] || 0) + 1; });
  assert.deepEqual(by, { dresses: 10, coords: 10, tops: 10, bottoms: 8, abayas: 8, unisex: 8 });
  assert.deepEqual(rows.map((r) => r.legacy_id), original.map((p) => p.id));
});
test('slugs unique and valid; categories/colours known; sizes present', () => {
  assert.equal(new Set(rows.map((r) => r.slug)).size, 54);
  for (const r of rows) {
    assert.match(r.slug, /^[a-z0-9]+(-[a-z0-9]+)*$/); assert.ok(CATEGORY_SLUGS.includes(r.category_slug));
    assert.ok(r.colors.length === 3 && r.colors.every((c) => COLOR_KEYS.includes(c))); assert.ok(r.sizes.length >= 4);
  }
});
test('price the customer pays is EXACTLY the original price; struck-through price is the original "was"', () => {
  original.forEach((p, i) => {
    const r = rows[i], pays = r.sale_price_pkr ?? r.price_pkr, was = r.sale_price_pkr != null ? r.price_pkr : 0;
    assert.equal(pays, p.price, p.name); assert.equal(was, p.was || 0, p.name);
    if (r.sale_price_pkr != null) assert.ok(r.sale_price_pkr < r.price_pkr, 'DB check sale < regular');
  });
});
test('new / best-seller flags preserved', () => {
  assert.deepEqual(rows.map((r) => r.is_new), original.map((p) => !!p.isNew));
  assert.deepEqual(rows.map((r) => r.is_bestseller), original.map((p) => !!p.best));
});
test('committed seed SQL matches the extraction (not stale) and is idempotent by design', () => {
  const committed = readFileSync(new URL('../supabase/05_seed_demo_products.sql', import.meta.url), 'utf8');
  assert.equal(committed, buildSeedSql(rows));
  assert.match(committed, /on conflict \(slug\) do nothing/);
  assert.equal((committed.match(/^\('z\d{3}'/gm) || []).length, 54);
  assert.ok(!/do update/i.test(committed), 'must never overwrite owner edits');
});
test('JSON data file matches too', () => {
  assert.deepEqual(JSON.parse(readFileSync(new URL('../data/demo-products.json', import.meta.url), 'utf8')), rows);
});
